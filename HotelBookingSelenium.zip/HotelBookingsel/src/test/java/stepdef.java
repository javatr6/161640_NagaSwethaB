


import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {
	
	
	private WebElement element;
	private WebDriver webdriver;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver","D:\\chrome\\chromedriver.exe");
		webdriver=new ChromeDriver();
	}
	
	@Given("^Open HotelBooking Login page$")
	public void open_HotelBooking_Login_page() throws Throwable {
		 webdriver.get("http://localhost:8081/HotelBookingsel/login.html");
	}

	@Given("^provide username$")
	public void provide_username() throws Throwable {
		webdriver.findElement(By.name("userName")).sendKeys("");
	}

	@When("^submit validate login$")
	public void submit_validate_login() throws Throwable {
		element=webdriver.findElement(By.className("btn"));
		element.submit();
	}

	@Then("^give error message$")
	public void give_error_message() throws Throwable {
		webdriver.findElement(By.id("userErrMsg"));
		webdriver.findElement(By.className("btn")).click();
		Thread.sleep(5000);
		webdriver.navigate().to("http://localhost:8081/HotelBookingsel/login.html");
	}

	@Given("^Open HotelBooking Login Page$")
	public void open_HotelBooking_Login_Page() throws Throwable {
		 webdriver.get("http://localhost:8081/HotelBookingsel/login.html");
	}

	@Given("^provide username and password$")
	public void provide_username_and_password() throws Throwable {
		webdriver.findElement(By.name("userName")).sendKeys("capgemini");
		   webdriver.findElement(By.name("userPwd")).sendKeys("");
	}

	@Then("^give the error message$")
	public void give_the_error_message() throws Throwable {
	    
	}

	@Given("^Open HotelBooking login page$")
	public void open_HotelBooking_login_page() throws Throwable {
	   
	}

	@Then("^navigate to hotelbooking$")
	public void navigate_to_hotelbooking() throws Throwable {
	    
	}




} 

