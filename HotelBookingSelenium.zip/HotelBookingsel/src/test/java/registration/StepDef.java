package registration;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	private WebDriver webdriver;
	private WebElement element;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver","D:\\chrome\\chromedriver.exe");
		webdriver=new ChromeDriver();
	}
	
	@Given("^Open Buspass registration page$")
	public void open_Buspass_registration_page() throws Throwable {
		webdriver.get("http://localhost:8081/BusPass/pages/requestForm.html");
	    
	}

	@Given("^provide employeeId,firstname,lastname,emailId,gender,designation,address,doj,location,pickuptime,pickuplocation$")
	public void provide_employeeId_firstname_lastname_emailId_gender_designation_address_doj_location_pickuptime_pickuplocation() throws Throwable {
		 webdriver.findElement(By.name("empid")).sendKeys("10011");
		   webdriver.findElement(By.name("fname")).sendKeys("sai");
		   webdriver.findElement(By.name("lname")).sendKeys("krishna");
		   webdriver.findElement(By.name("emailid")).sendKeys("saikk@gmail.com");
		   webdriver.findElement(By.id("male")).click();
		   //webdriver.findElement(By.name("designation")).isSelected();
		   new Select(webdriver.findElement(By.name("designation"))).selectByVisibleText("Manager");
		   webdriver.findElement(By.name("address")).sendKeys("chennai");
		   //date
		   webdriver.findElement(By.name("doj")).sendKeys("11/06/2018");
		   //new Select(webdriver.findElement(By.name("doj"))).selectByVisibleText("11/06/2018");
		   new Select(webdriver.findElement(By.name("location"))).selectByVisibleText("Chennai PCT");
		   new Select(webdriver.findElement(By.name("pickuplocation"))).selectByVisibleText("karapakam");
		   //time
		   webdriver.findElement(By.name("pickuptime")).sendKeys("0200PM");
		   //new Select(webdriver.findElement(By.name("pickuptime"))).selectByVisibleText("02:00 AM");
		   
		 
		
		
	}

	@When("^submit$")
	public void submit() throws Throwable {
		element=webdriver.findElement(By.name("submit"));
		element.submit();
	    
	}

	@Then("^navigate to successpage$")
	public void navigate_to_successpage() throws Throwable {
		webdriver.navigate().to("http://localhost:8081/BusPass/pages/Success.html");
	}


}
