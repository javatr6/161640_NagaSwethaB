package com.capg.manytomany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Delegates {
	@Id
	private int delegateid;
	private String delegatename;
	@ManyToMany
	@JoinTable(name="event_delegate",joinColumns= {@JoinColumn(name="delegates")},inverseJoinColumns= {@JoinColumn(name="events")})
	private List<Events> events=new ArrayList<>();
	public Delegates() {
		super();
	}
	public Delegates(int delegateid, String delegatename) {
		super();
		this.delegateid = delegateid;
		this.delegatename = delegatename;
	}
	public int getDelegateid() {
		return delegateid;
	}
	public void setDelegateid(int delegateid) {
		this.delegateid = delegateid;
	}
	public String getDelegatename() {
		return delegatename;
	}
	public void setDelegatename(String delegatename) {
		this.delegatename = delegatename;
	}
	public List<Events> getEvents() {
		return events;
	}
	public void setEvents(List<Events> events) {
		this.events = events;
	}
	@Override
	public String toString() {
		return "Delegates [delegateid=" + delegateid + ", delegatename=" + delegatename + ", events=" + events + "]";
	}
	
	
	

}
