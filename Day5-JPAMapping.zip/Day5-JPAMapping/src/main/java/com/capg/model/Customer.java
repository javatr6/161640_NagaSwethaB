package com.capg.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Table(name="cust")
@Entity
public class Customer {
	@Id
	@GeneratedValue
	private int custid;
	private String firstName;
	private String lastName;
	private double regfees;
	@OneToOne
	@JoinColumn(name="addfk")
	private Address address;
	public Customer() {
		super();
	}
	
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Customer(int custid, String firstName, String lastName, double regfees) {
		super();
		this.custid = custid;
		this.firstName = firstName;
		this.lastName = lastName;
		this.regfees = regfees;
	}
	
	public Customer(String firstName, String lastName, double regfees) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.regfees = regfees;
	}
	public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public double getRegfees() {
		return regfees;
	}
	public void setRegfees(double regfees) {
		this.regfees = regfees;
	}
	@Override
	public String toString() {
		return "Customer [custid=" + custid + ", firstName=" + firstName + ", lastName=" + lastName + ", regfees="
				+ regfees + "]";
	}
	

}
