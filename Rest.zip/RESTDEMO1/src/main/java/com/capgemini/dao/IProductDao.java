package com.capgemini.dao;

import java.util.List;

import com.capgemini.services.Product;

public interface IProductDao {
	public  List<Product> getAllProducts();
	public  List<Product> deleteProduct(int productId);
	public  List<Product> addProduct(Product product);
	public  Product findProduct(int productId);
	public  List<Product> updateProduct(Product product);
	

}
