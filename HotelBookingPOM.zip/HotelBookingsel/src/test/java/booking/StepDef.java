package booking;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import bean.BookingBean;
import bean.SuccessPage;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	private WebDriver driver;
	private BookingBean bookingBean;
	private SuccessPage successPage;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver","D:\\chrome\\chromedriver.exe");
		driver=new ChromeDriver();
		bookingBean=new BookingBean(driver);
		successPage=new SuccessPage(driver);
	}
	
	@Given("^open Hotel Booking page$")
	public void open_Hotel_Booking_page() throws Throwable {
		driver.get("http://localhost:8081/HotelBookingsel/pages/hotelbooking.html");
		String head = driver.findElement(By.xpath("/html/body/div/h2")).getText();
		assertEquals("Hotel Booking Form",head);
	}

	@Given("^Personel and payment details$")
	public void personel_and_payment_details() throws Throwable {
		bookingBean.setFirstName("Swetha");
		bookingBean.setLastName("Naga");
		bookingBean.setEmail("swetha@gmail.com");
		bookingBean.setPhoneNumber("9876543210");
		bookingBean.setAddress("Chennai");
		bookingBean.setCity("Chennai");
		bookingBean.setState("Tamilnadu");
		bookingBean.setNofguestStay("2");
		bookingBean.setCardHolderName("swetha");
		bookingBean.setDebitCardNumber("56271612576");
		bookingBean.setCvv("566");
		bookingBean.setExpMonth("11");
		bookingBean.setExpYear("2018");
		Thread.sleep(5000);
	    
	}

	@When("^Personel And payment details are not empty$")
	public void personel_And_payment_details_are_not_empty() throws Throwable {
		bookingBean.onSubmit_navigate_to_mainPage();
		Thread.sleep(1000);
	}

	@Then("^navigate to success page$")
	public void navigate_to_success_page() throws Throwable {
		driver.navigate().to("http://localhost:8081/HotelBookingsel/pages/Success.html");
	}

	@Given("^Personel and payment details are null$")
	public void personel_and_payment_details_are_null() throws Throwable {
	    
	}

	@When("^Personel And payment details are empty$")
	public void personel_And_payment_details_are_empty() throws Throwable {
	   
	}

	@Then("^show alert messages$")
	public void show_alert_messages() throws Throwable {
	   
	}



}
