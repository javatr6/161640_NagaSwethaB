package bean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class BookingBean {
	private String firstName;
	private String lastName;
	private String email;
	private String phoneNumber;
	private String address;
	private String city;
	private String state;
	private String nofguestStay;
	private String nofroomsBooked;
	private String cardHolderName;
	private String debitCardNumber;
	private String cvv;
	private String expMonth;
	private String expYear;

	private String confirmBtn;
	private WebDriver driver;

	public BookingBean() {
		super();
	}
	public BookingBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}

	public String getConfirmBtn() {
		return confirmBtn;
	}


	public void setConfirmBtn(String confirmBtn) {
		this.confirmBtn = confirmBtn;
	}


	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		driver.findElement(By.name("txtFN")).sendKeys(firstName);
		this.firstName = firstName;
	}
	public String getLastName() {

		return lastName;
	}
	public void setLastName(String lastName) {
		driver.findElement(By.name("txtLN")).sendKeys("Naga");
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		driver.findElement(By.name("Email")).sendKeys("swetha@gmail.com");
		this.email = email;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		driver.findElement(By.name("Phone")).sendKeys("9876543210");
		this.phoneNumber = phoneNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		driver.findElement(By.xpath("/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("Chennai");
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		WebElement mySelectElement = driver.findElement(By.name("city"));
		Select dropdown= new Select(mySelectElement);
		dropdown.selectByVisibleText("Chennai");
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		WebElement mySelectstate = driver.findElement(By.name("state"));
		Select dropdownState= new Select(mySelectstate);
		dropdownState.selectByVisibleText("Tamilnadu");
		this.state = state;
	}
	public String getNofguestStay() {
		return nofguestStay;
	}
	public void setNofguestStay(String nofguestStay) {
		WebElement persons = driver.findElement(By.name("persons"));
		Select dropdownpersons= new Select(persons);
		dropdownpersons.selectByVisibleText("2");
		this.nofguestStay = nofguestStay;
	}
	public String getNofroomsBooked() {
		return nofroomsBooked;
	}
	public void setNofroomsBooked(String nofroomsBooked) {
		this.nofroomsBooked = nofroomsBooked;
	}
	public String getCardHolderName() {
		return cardHolderName;
	}
	public void setCardHolderName(String cardHolderName) {
		driver.findElement(By.xpath("//*[@id=\"txtCardholderName\"]")).sendKeys("Swetha");
		this.cardHolderName = cardHolderName;
	}
	public String getDebitCardNumber() {
		return debitCardNumber;
	}
	public void setDebitCardNumber(String debitCardNumber) {
		driver.findElement(By.name("debit")).sendKeys("459175008956733");
		this.debitCardNumber = debitCardNumber;
	}
	public String getCvv() {
		return cvv;
	}
	public void setCvv(String cvv) {
		driver.findElement(By.name("cvv")).sendKeys("554");
		this.cvv = cvv;
	}
	public String getExpMonth() {
		return expMonth;
	}
	public void setExpMonth(String expMonth) {
		driver.findElement(By.name("month")).sendKeys("11");
		this.expMonth = expMonth;
	}
	public String getExpYear() {
		return expYear;
	}
	public void setExpYear(String expYear) {
		driver.findElement(By.name("year")).sendKeys("2018");
		this.expYear = expYear;
	}
	public void onSubmit_navigate_to_mainPage() {

		/*setUserName(userName);
		setUserpassword(usrpassword);*/

		WebElement confirm=driver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));
		confirm.click();
	}



}
